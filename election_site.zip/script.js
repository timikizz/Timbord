const ctx = document.getElementById('electionChart');
if(ctx){
  let storedVotes = JSON.parse(localStorage.getItem('votes')) || {
    "Candidate A": 350,
    "Candidate B": 250,
    "Candidate C": 150
  };

  const labels = Object.keys(storedVotes);
  const data = Object.values(storedVotes);

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Number of Votes',
        data: data,
        backgroundColor: ['#2b7a0b', '#4caf50', '#81c784'],
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: { beginAtZero: true }
      }
    }
  });
}